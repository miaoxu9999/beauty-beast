export class Activity {
  title: any;
  start: any;
}
