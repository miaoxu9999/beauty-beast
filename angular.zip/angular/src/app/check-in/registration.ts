export class Registration{
  registrationid: number;
  meetingName: string;
  activityTime: any;
}
