export class Page{
 pageNum: number;
 pageStatus: string;
}
