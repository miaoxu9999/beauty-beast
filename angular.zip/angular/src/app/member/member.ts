export class Member {
  memberid: number;
  name: any;
  studentID: string;
  password: string;
  // memberDetail: any;
  privilegeType: number;
  // registration_temps: any;

  tjsq: any;//提交入党申请书的日期
  rdjjfz: any;//称为 入党积极分子的日期
  fzdx: any; //成为 发展对象的日期
  rdrq: any; // 入党日期

}
