package com.example.party.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.Assert.*;

/**
 * @Author: miaoxu
 * @Description:
 * @Date: Created in 2017/12/18 0018
 * @Modified By :
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class Registration_ControllerTest {

    @Autowired
    MockMvc mockMvc;
    @Test
    public void addRegistration() throws Exception {

    }

    @Test
    public void deleteRegistration() throws Exception {

    }

    @Test
    public void registrationList() throws Exception {

    }

    @Test
    public void getAllPeopleRegistration() throws Exception {

    }

}