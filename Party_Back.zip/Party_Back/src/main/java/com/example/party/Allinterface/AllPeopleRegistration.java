package com.example.party.Allinterface;

import com.example.party.RegistrationType;
import com.example.party.model.PartyMember;
import com.example.party.model.Registration;
import com.example.party.model.RegistrationTemp;

/**
 * @Author: miaoxu
 * @Description: 所有人的签到情况
 * @Date: Created in 2017/12/13 0013
 * @Modified By :
 */
public interface AllPeopleRegistration {
//    PartyMember getPartyMember();
//    Registration getRegistration();
//    RegistrationTemp getRegistrationTemp();
//    RegistrationType getRegistrationType();
    int getmemberid();
//    int registration_registration_id();
}
